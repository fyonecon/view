/*
*   主入口js，一般不要做修改。
* */


// 浏览器环境检查，主要检测是否支持ES6语法
(function () {
    try{
        let check = 1;
        new Promise(function(resolve, reject) {
            if (check === 1){
                check++;
                resolve();
            } else {
                check--;
                reject();
            }
        }).then(function () {
            const map = new Map([
                ["check", check],
            ]);
            map.get("check");
            console.log("ES6 YES");
        });

    }catch (e) {
        alert("浏览器版本不支持ES6语法。");
        window.location.replace("help.html");
    }
})();

// 日志函数
function console_log(txt) {
    if (txt === 0 || txt === "0") {

    }else {
        if (!txt){txt = "空txt";}
    }
    debug === true ? console.log(txt): "";
}

// 监听url是否发生变化，确保页面跳转成功
(function () {
    let url = window.location.href;

    window.onhashchange = function () {
        let now_url = window.location.href;
        if (url !== now_url){
            window.location.reload();
        }else {
            console_log("跳过url变化检测。");
        }
    };

})();

// 加载框架模块文件
(function () {

    let depend = {  // 依赖函数
        "getThisUrlParam": function (url, key) {  // 获取url中的参数
            let url_str = "";
            if(!url){
                url_str = window.location.href;
            }else {
                url_str = url;
            }
            // 正则匹配url中的参数，如果存在键，则返回键的值，如果不存在则返回null
            let regExp = new RegExp("([?]|&|#)" + key + "=([^&|^#]*)(&|$|#)");
            let result = url_str.match(regExp);
            if (result) {
                return decodeURIComponent(result[2]); // 转义还原参数
            } else {
                return null;
            }
        },
        "page_file": function (pages_index) {  // 添加页面js、css资源文件

            if (pages_index === null){
                console.log("pages参数好像未定义，页面和框架数据将不能渲染");
                setTimeout(function () {
                    window.location.replace(route_404);  // 则进入默认页
                }, 1000);
                return;
            }

            let head = document.head || document.getElementsByTagName("head")[0];
            let file = pages[pages_index].file[0];
            let had_onload = 0;

            for (let i=0; i<file.css.length; i++){
                let link = document.createElement('link');
                link.setAttribute("href", file.css[i]);
                link.setAttribute("rel", "stylesheet");
                head.appendChild(link);
            }
            for (let i=0; i<file.js.length; i++){

                let script = document.createElement("script");
                script.setAttribute("src", file.js[i]);
                head.appendChild(script);

                script.onload = function () {
                    had_onload++;
                    if (had_onload === file.js.length) {
                        depend.page_all_js_has();
                    }
                };

            }

        },
        "page_all_js_has": function () {  // 页面全部js加载完执行
            try {
                console.log("框架初始化完成。");
                setTimeout(function () {
                    document.getElementsByClassName("loading-div")[0].classList.add("hide");
                }, 200);
                start_this_page();
            }catch (e) {
                console.log("start_this_page()" + "页面起始模块函数未定义，但是此函数可忽略。");
            }
        },

    };

    let page_name = "";     // 拉取哪个html文件块
    let _file = "";         // 真实文件路径+文件名
    let pages_index = null; // 页面资源索引
    
    new Promise(function(resolve, reject) {

        new Promise(function(_resolve, _reject) {  // 处理页面路由
            page_name = depend.getThisUrlParam("", "route");
            for (let i=0; i<pages.length; i++){ // 获取真正文件路径名
                if (pages[i].route === page_name){
                    _file = pages[i].file_path;
                    document.getElementsByTagName("title")[0].innerHTML = pages[i].title;
                    pages_index = i;
                }
            }
            setTimeout(function () {
                if (pages_index === null){
                    console.log("页面没有正确路由#route=xxx");
                    window.location.replace(route_default);  // 则进入默认页
                    _resolve();
                }else{
                    _resolve();
                }
            },20);
        }).then(function () {
            const file_path = "pages/" + _file;

            $.ajax({ // 利用ajax的get请求获取文本内容
                url: file_path,
                async: true,
                success: function (data) {
                    document.getElementById("depend").innerHTML = data; // 将模块渲染入主文件

                    resolve();
                },
                error: function (error) {
                    console.log("缺失模块html文件=" + error);
                    alert("1.非同源政策限制模块文件的拉取；2.本应用需要服务器环境。");
                    reject();
                }
            });

        });

    }).then(function () {

        let head = document.head || document.getElementsByTagName("head")[0];
        let had_onload = 0;

        // 页面渲染完毕，开始执行公共css、js引入
        for (let i=0; i<page_public_file.css.length; i++){
            let link = document.createElement('link');
            link.setAttribute("href", page_public_file.css[i]);
            link.setAttribute("rel", "stylesheet");
            head.appendChild(link);
        }
        for (let i=0; i<page_public_file.js.length; i++){
            let script = document.createElement("script");
            script.setAttribute("src", page_public_file.js[i]);
            head.appendChild(script);

            script.onload = function () {
                had_onload++;
                if (had_onload === page_public_file.js.length) {
                    // 公共js加载完成后开始加载页面js
                    depend.page_file(pages_index);
                }
            };

        }
    });

})();